Usage instructions

- if the element has a TITLE attribute:
	$("#some-element").simpletooltip();
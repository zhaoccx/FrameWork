$(document).ready(function(){
	$(".with-tooltip").simpletooltip();
});
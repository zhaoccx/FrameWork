/*
 * Format:      Javascript Plugin : jQuery Framework
 * Author:      jmcclure located_at sonicradish.com
 * Copyright:   2006-2009 sonicradish.com
 * License:     You may use this code on your site and alter it as you see fit, all I ask is that you include a reference to my original version and send me any bug fixes that you find.
 * Provided:    As is, without liability.
 *
 * Revision:    0.65
 * Updated:     2008-03-24 - Version 0.64
 *              2009-03-03 - Version 0.65
 *
 *
 * IMPORTANT NOTE: This version has only been tested to work with jQuery 1.2.3, and has not been updated to work with jQuery 1.3!
 *
 */

	Usage:
		The easiest way to get up in running is to work with the static_demo.html example.

Files in Download:

ajax_demo.html		// AJAX Example File
ajax.php		// Sample AJAX Menu File in PHP
jGlideMenu.css		// Menu Style Definitions
jquery.dimensions.js	// jQuery Dimensions Plugin
jQuery.jGlideMenu.js	// jGlide Menu Plugin
jquery-latest.pack.js	// jQuery Library
static_demo.html	// Inline Example File
<several image files>
